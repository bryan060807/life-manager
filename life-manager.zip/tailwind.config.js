/** @type {import('tailwindcss').Config} */
export default {
  // We toggle dark mode by adding/removing the 'dark' class on <html>
  darkMode: 'class',

  // Tell Tailwind where to look for class names
  content: [
    './index.html',
    './src/**/*.{js,ts,jsx,tsx}',
  ],

  theme: {
    extend: {
      // You can customize tokens here if needed
      borderRadius: {
        '2xl': '1rem', // keep in sync with CSS variable --radius if you change it
      },
      // example font-smoothing & shadows could go here if desired
    },
  },

  // Add plugins here if you want (kept empty for a clean baseline)
  plugins: [
    // require('@tailwindcss/forms'), // uncomment if you want nicer default form styles
    // require('@tailwindcss/typography'),
    // require('@tailwindcss/aspect-ratio'),
  ],
};
