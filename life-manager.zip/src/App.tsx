// src/App.tsx
import React, { useEffect, useMemo, useState } from "react";
import {
  CheckCircle2,
  Circle,
  Clock,
  Trash2,
  Edit3,
  Plus,
  RefreshCcw,
  CalendarDays,
  CalendarRange,
  Target,
  Upload,
  Download,
  Sun,
  Moon,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

// ===== Types =====
export type Timeframe = "daily" | "weekly" | "longterm";
export type Priority = 1 | 2 | 3 | 4 | 5;
export type Task = {
  id: string;
  title: string;
  notes?: string;
  timeframe: Timeframe;
  priority: Priority;
  status: "todo" | "doing" | "done";
  dueDate?: string; // ISO date
  weekday?: number; // 0-6 Sun..Sat
  createdAt: string; // ISO
  updatedAt: string; // ISO
  lastResetKey?: string; // for auto-resets
};

// ===== Storage =====
const STORAGE_KEY = "lifeManager.tasks.v2"; // bump for new version
const THEME_KEY = "lifeManager.theme";

const loadTasks = (): Task[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};
const saveTasks = (tasks: Task[]) =>
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));

const uid = () =>
  crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2);

const getTodayKey = () => new Date().toISOString().slice(0, 10);
function getWeekKey() {
  const now = new Date();
  const tmp = new Date(
    Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())
  );
  const dayNum = (tmp.getUTCDay() + 6) % 7;
  tmp.setUTCDate(tmp.getUTCDate() - dayNum + 3);
  const firstThursday = new Date(Date.UTC(tmp.getUTCFullYear(), 0, 4));
  const week =
    1 +
    Math.round(
      ((tmp.getTime() - firstThursday.getTime()) / 86400000 - 3) / 7
    );
  return `${tmp.getUTCFullYear()}-W${String(week).padStart(2, "0")}`;
}

const cn = (...xs: (string | false | null | undefined)[]) =>
  xs.filter(Boolean).join(" ");

// ===== UI primitives =====
const Button = ({
  children,
  onClick,
  variant = "solid",
  className,
  type,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: "solid" | "outline" | "ghost";
  className?: string;
  type?: "button" | "submit";
}) => (
  <button
    type={type ?? "button"}
    onClick={onClick}
    className={cn(
      "inline-flex items-center gap-2 rounded-2xl px-4 py-2 text-sm transition",
      variant === "solid" &&
        "bg-black text-white hover:opacity-90 dark:bg-white dark:text-black",
      variant === "outline" &&
        "border border-gray-300 hover:bg-gray-50 dark:border-neutral-700 dark:hover:bg-neutral-800",
      variant === "ghost" && "hover:bg-gray-100 dark:hover:bg-neutral-800",
      className
    )}
  >
    {children}
  </button>
);

const Card = ({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) => (
  <div
    className={cn(
      "rounded-2xl border bg-white p-4 shadow-sm dark:border-neutral-800 dark:bg-neutral-900",
      className
    )}
  >
    {children}
  </div>
);

const StatChip = ({ label }: { label: string }) => (
  <span className="inline-flex items-center rounded-full bg-gray-100 px-3 py-1 text-xs font-medium dark:bg-neutral-800">
    {label}
  </span>
);

const PriorityDots = ({ value }: { value: Priority }) => (
  <div className="flex items-center gap-1" aria-label={`Priority ${value}`}>
    {Array.from({ length: 5 }).map((_, i) => (
      <span
        key={i}
        className={cn(
          "h-2.5 w-2.5 rounded-full border",
          i < value ? "bg-black dark:bg-white" : "bg-transparent"
        )}
      ></span>
    ))}
  </div>
);

const Segmented = ({
  value,
  onChange,
}: {
  value: Timeframe;
  onChange: (v: Timeframe) => void;
}) => (
  <div className="inline-grid grid-cols-3 overflow-hidden rounded-xl border p-0.5 dark:border-neutral-700">
    {([
      ["daily", <CalendarDays className="h-4 w-4" key="i" />],
      ["weekly", <Clock className="h-4 w-4" key="i" />],
      ["longterm", <CalendarRange className="h-4 w-4" key="i" />],
    ] as const).map(([k, icon]) => (
      <button
        key={k}
        onClick={() => onChange(k as Timeframe)}
        className={cn(
          "flex items-center justify-center gap-2 rounded-lg px-3 py-2 text-sm",
          value === k
            ? "bg-black text-white dark:bg-white dark:text-black"
            : "hover:bg-gray-100 dark:hover:bg-neutral-800"
        )}
      >
        {icon}
        <span className="capitalize">{k === "longterm" ? "Long-term" : k}</span>
      </button>
    ))}
  </div>
);

// ===== Main App =====
export default function LifeManagerApp() {
  const [tasks, setTasks] = useState<Task[]>(loadTasks());
  const [filter, setFilter] = useState<Timeframe | "all">("daily");
  const [query, setQuery] = useState("");
  const [editing, setEditing] = useState<Task | null>(null);
  const [theme, setTheme] = useState<string>(() => {
    const saved = localStorage.getItem(THEME_KEY);
    if (saved) return saved;
    const prefersDark =
      typeof window !== "undefined" &&
      window.matchMedia &&
      window.matchMedia("(prefers-color-scheme: dark)").matches;
    return prefersDark ? "dark" : "light";
  });

  // Theme
  useEffect(() => {
    const root = document.documentElement;
    if (theme === "dark") root.classList.add("dark");
    else root.classList.remove("dark");
    localStorage.setItem(THEME_KEY, theme);
  }, [theme]);

  // Persist
  useEffect(() => saveTasks(tasks), [tasks]);

  // Auto reset on mount
  useEffect(() => {
    const todayKey = getTodayKey();
    const weekKey = getWeekKey();
    let changed = false;
    const next = tasks.map((t) => {
      const n = { ...t };
      if (t.timeframe === "daily") {
        if (t.lastResetKey !== todayKey && t.status === "done") n.status = "todo";
        if (t.lastResetKey !== todayKey) {
          n.lastResetKey = todayKey;
          changed = true;
        }
      }
      if (t.timeframe === "weekly") {
        const key = `${weekKey}-${t.weekday ?? ""}`;
        if (t.lastResetKey !== key && t.status === "done") n.status = "todo";
        if (t.lastResetKey !== key) {
          n.lastResetKey = key;
          changed = true;
        }
      }
      return n;
    });
    if (changed) setTasks(next);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Derived
  const counts = useMemo(
    () => ({
      all: tasks.length,
      daily: tasks.filter((t) => t.timeframe === "daily").length,
      weekly: tasks.filter((t) => t.timeframe === "weekly").length,
      longterm: tasks.filter((t) => t.timeframe === "longterm").length,
      done: tasks.filter((t) => t.status === "done").length,
    }),
    [tasks]
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();

    return tasks
      .filter((t) => (filter === "all" ? true : t.timeframe === filter))
      .filter((t) =>
        q ? `${t.title}\n${t.notes ?? ""}`.toLowerCase().includes(q) : true
      )
      .sort((a, b) => {
        // status: todo first
        if (a.status !== b.status) return a.status === "todo" ? -1 : 1;
        // priority: higher first
        if (b.priority !== a.priority) return b.priority - a.priority;
        // due date: earlier first (undefined last)
        const ad = a.dueDate ? new Date(a.dueDate).getTime() : Infinity;
        const bd = b.dueDate ? new Date(b.dueDate).getTime() : Infinity;
        if (ad !== bd) return ad - bd;
        // recency
        return (
          new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
        );
      });
  }, [tasks, filter, query]);

  // Actions
  function addTask(
    t: Omit<Task, "id" | "createdAt" | "updatedAt" | "lastResetKey">
  ) {
    const now = new Date().toISOString();
    const next: Task = { id: uid(), createdAt: now, updatedAt: now, ...t };
    setTasks([next, ...tasks]);
    setFilter(t.timeframe);
  }
  const toggleTask = (id: string) =>
    setTasks(
      tasks.map((t) =>
        t.id === id
          ? {
              ...t,
              status: t.status === "done" ? "todo" : "done",
              updatedAt: new Date().toISOString(),
            }
          : t
      )
    );
  const removeTask = (id: string) =>
    setTasks(tasks.filter((t) => t.id !== id));
  function saveEdit(t: Task) {
    setTasks(
      tasks.map((x) =>
        x.id === t.id ? { ...x, ...t, updatedAt: new Date().toISOString() } : x
      )
    );
    setEditing(null);
  }
  function resetPeriodic() {
    const todayKey = getTodayKey();
    const weekKey = getWeekKey();
    setTasks(
      tasks.map((t) => {
        if (t.timeframe === "daily")
          return { ...t, status: "todo", lastResetKey: todayKey };
        if (t.timeframe === "weekly")
          return {
            ...t,
            status: "todo",
            lastResetKey: `${weekKey}-${t.weekday ?? ""}`,
          };
        return t;
      })
    );
  }

  // Export / Import
  function exportJSON() {
    const blob = new Blob([JSON.stringify(tasks, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "life-manager-tasks.json";
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 500);
  }
  function importJSON(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(String(reader.result));
        if (Array.isArray(data)) setTasks(data);
      } catch {
        // ignore parse error
      }
    };
    reader.readAsText(file);
    e.currentTarget.value = "";
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 transition-colors dark:bg-neutral-950 dark:text-neutral-100">
      {/* Header */}
      <div className="sticky top-0 z-20 border-b bg-white/80 backdrop-blur dark:border-neutral-800 dark:bg-neutral-950/70">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-2xl bg-black text-white dark:bg-white dark:text-black">
              <Target className="h-4 w-4" />
            </div>
            <h1 className="text-xl font-semibold">Life Manager</h1>
          </div>
          <div className="flex items-center gap-2">
            <StatChip label={`Daily: ${counts.daily}`} />
            <StatChip label={`Weekly: ${counts.weekly}`} />
            <StatChip label={`Long-term: ${counts.longterm}`} />
            <StatChip label={`Done: ${counts.done}`} />
            <Button
              variant="ghost"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            >
              {theme === "dark" ? (
                <Sun className="h-4 w-4" />
              ) : (
                <Moon className="h-4 w-4" />
              )}
            </Button>
          </div>
        </div>
      </div>

      <main className="mx-auto max-w-5xl px-4 py-6">
        {/* Add Task */}
        <Card>
          <div className="mb-3 flex items-center gap-2">
            <Plus className="h-5 w-5" />
            <h2 className="text-lg font-semibold">Add Task</h2>
          </div>
          <AddTaskForm onAdd={addTask} />
        </Card>

        {/* Controls */}
        <div className="my-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-3">
            <Tabs value={filter} onChange={setFilter} />
            <Button variant="outline" onClick={resetPeriodic}>
              <RefreshCcw className="h-4 w-4" /> Reset Daily/Weekly
            </Button>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <input
                className="w-64 rounded-xl border bg-white px-10 py-2 text-sm placeholder:text-gray-400 dark:border-neutral-700 dark:bg-neutral-900"
                placeholder="Search…"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
              <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 opacity-60">
                🔎
              </span>
            </div>
            <Button variant="outline" onClick={exportJSON}>
              <Download className="h-4 w-4" /> Export
            </Button>
            <label className="inline-flex cursor-pointer items-center gap-2 rounded-2xl border px-4 py-2 text-sm hover:bg-gray-50 dark:border-neutral-700 dark:hover:bg-neutral-800">
              <Upload className="h-4 w-4" /> Import
              <input
                type="file"
                accept="application/json"
                onChange={importJSON}
                className="hidden"
              />
            </label>
          </div>
        </div>

        {/* List */}
        <div className="grid gap-3">
          <AnimatePresence>
            {filtered.length === 0 ? (
              <Card>
                <div className="text-sm opacity-80">
                  No tasks yet. Add something and crush your day ✨
                </div>
              </Card>
            ) : (
              filtered.map((t) => (
                <motion.div
                  key={t.id}
                  layout
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                >
                  <TaskRow
                    task={t}
                    onToggle={toggleTask}
                    onEdit={setEditing}
                    onDelete={removeTask}
                  />
                </motion.div>
              ))
            )}
          </AnimatePresence>
        </div>
      </main>

      {editing && (
        <EditModal
          task={editing}
          onClose={() => setEditing(null)}
          onSave={saveEdit}
        />
      )}

      <footer className="mx-auto max-w-5xl px-4 py-10 text-center text-xs opacity-70">
        Your data stays in your browser (localStorage). Export backups
        regularly.
      </footer>
    </div>
  );
}

// ===== Subcomponents =====
function Tabs({
  value,
  onChange,
}: {
  value: Timeframe | "all";
  onChange: (v: Timeframe | "all") => void;
}) {
  const tabs: { key: Timeframe | "all"; label: string; icon: React.ReactNode }[] =
    [
      { key: "all", label: "All", icon: <Target className="h-4 w-4" /> },
      { key: "daily", label: "Daily", icon: <CalendarDays className="h-4 w-4" /> },
      { key: "weekly", label: "Weekly", icon: <Clock className="h-4 w-4" /> },
      {
        key: "longterm",
        label: "Long-term",
        icon: <CalendarRange className="h-4 w-4" />,
      },
    ];
  return (
    <div className="inline-flex overflow-hidden rounded-2xl border dark:border-neutral-700">
      {tabs.map((t) => (
        <button
          key={t.key}
          onClick={() => onChange(t.key)}
          className={cn(
            "flex items-center gap-2 px-4 py-2 text-sm",
            value === t.key
              ? "bg-black text-white dark:bg-white dark:text-black"
              : "bg-white hover:bg-gray-50 dark:bg-neutral-900 dark:hover:bg-neutral-800"
          )}
        >
          {t.icon}
          {t.label}
        </button>
      ))}
    </div>
  );
}

function TaskRow({
  task,
  onToggle,
  onEdit,
  onDelete,
}: {
  task: Task;
  onToggle: (id: string) => void;
  onEdit: (t: Task) => void;
  onDelete: (id: string) => void;
}) {
  return (
    <Card className="group grid grid-cols-[auto_1fr_auto_auto] items-start gap-4 p-3 md:grid-cols-[auto_1fr_auto_auto]">
      <button
        onClick={() => onToggle(task.id)}
        className="mt-0.5 rounded-full p-1 hover:bg-gray-100 dark:hover:bg-neutral-800"
        aria-label={task.status === "done" ? "Mark todo" : "Mark done"}
      >
        {task.status === "done" ? (
          <CheckCircle2 className="h-6 w-6" />
        ) : (
          <Circle className="h-6 w-6" />
        )}
      </button>
      <div>
        <div
          className={cn(
            "text-sm font-medium",
            task.status === "done" && "line-through opacity-60"
          )}
        >
          {task.title}
        </div>
        {task.notes && (
          <div className="mt-1 whitespace-pre-wrap text-xs opacity-80">
            {task.notes}
          </div>
        )}
        <div className="mt-2 flex flex-wrap items-center gap-2 text-xs">
          <span className="inline-flex items-center gap-1 rounded-full bg-gray-100 px-2.5 py-1 dark:bg-neutral-800">
            <Clock className="h-3.5 w-3.5" />
            {task.timeframe === "daily"
              ? "Daily"
              : task.timeframe === "weekly"
              ? `Weekly${
                  typeof task.weekday === "number"
                    ? ` • ${["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][task.weekday]}`
                    : ""
                }`
              : "Long-term"}
          </span>
          {task.dueDate && (
            <span className="inline-flex items-center gap-1 rounded-full bg-gray-100 px-2.5 py-1 dark:bg-neutral-800">
              <CalendarRange className="h-3.5 w-3.5" /> Due{" "}
              {new Date(task.dueDate).toLocaleDateString()}
            </span>
          )}
          <div className="ml-1">
            <PriorityDots value={task.priority} />
          </div>
        </div>
      </div>
      <Button
        variant="ghost"
        className="opacity-60 transition hover:opacity-100"
        onClick={() => onEdit(task)}
      >
        <Edit3 className="h-4 w-4" /> Edit
      </Button>
      <Button
        variant="ghost"
        className="text-red-600 opacity-60 transition hover:opacity-100 dark:text-red-400"
        onClick={() => onDelete(task.id)}
      >
        <Trash2 className="h-4 w-4" /> Delete
      </Button>
    </Card>
  );
}

function AddTaskForm({
  onAdd,
}: {
  onAdd: (t: Omit<Task, "id" | "createdAt" | "updatedAt" | "lastResetKey">) => void;
}) {
  const [title, setTitle] = useState("");
  const [notes, setNotes] = useState("");
  const [timeframe, setTimeframe] = useState<Timeframe>("daily");
  const [priority, setPriority] = useState<Priority>(3);
  const [weekday, setWeekday] = useState<number>(new Date().getDay());
  const [dueDate, setDueDate] = useState<string>("");

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    onAdd({
      title: title.trim(),
      notes: notes.trim() || undefined,
      timeframe,
      priority,
      status: "todo",
      weekday: timeframe === "weekly" ? weekday : undefined,
      dueDate: timeframe === "longterm" ? dueDate || undefined : undefined,
    });
    setTitle("");
    setNotes("");
  }

  return (
    <form
      onSubmit={submit}
      className="grid grid-cols-1 items-end gap-3 md:grid-cols-[1.5fr_auto_auto_auto_auto]"
    >
      <div className="flex flex-col gap-1">
        <label className="text-xs opacity-70">Task</label>
        <input
          className="rounded-xl border bg-white px-3 py-2 text-sm dark:border-neutral-700 dark:bg-neutral-900"
          placeholder="What do you need to do?"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-xs opacity-70">When</label>
        <Segmented value={timeframe} onChange={setTimeframe} />
      </div>
      {timeframe === "weekly" && (
        <div className="flex flex-col gap-1">
          <label className="text-xs opacity-70">Weekday</label>
          <select
            className="rounded-xl border bg-white px-3 py-2 text-sm dark:border-neutral-700 dark:bg-neutral-900"
            value={weekday}
            onChange={(e) => setWeekday(parseInt(e.target.value))}
          >
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d, i) => (
              <option key={d} value={i}>
                {d}
              </option>
            ))}
          </select>
        </div>
      )}
      {timeframe === "longterm" && (
        <div className="flex flex-col gap-1">
          <label className="text-xs opacity-70">Due</label>
          <input
            type="date"
            className="rounded-xl border bg-white px-3 py-2 text-sm dark:border-neutral-700 dark:bg-neutral-900"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
          />
        </div>
      )}
      {timeframe === "daily" && <div className="hidden md:block" />}
      <div className="flex flex-col gap-1">
        <label className="text-xs opacity-70">Priority</label>
        <div className="flex items-center gap-3">
          <input
            type="range"
            min={1}
            max={5}
            value={priority}
            onChange={(e) => setPriority(parseInt(e.target.value) as Priority)}
          />
          <PriorityDots value={priority} />
        </div>
      </div>
      <Button type="submit" className="md:ml-auto">
        <Plus className="h-4 w-4" /> Add
      </Button>
      <div className="md:col-span-5">
        <label className="mb-1 block text-xs opacity-70">Notes</label>
        <textarea
          rows={2}
          className="w-full rounded-xl border bg-white px-3 py-2 text-sm dark:border-neutral-700 dark:bg-neutral-900"
          placeholder="Optional notes…"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
        />
      </div>
    </form>
  );
}

function EditModal({
  task,
  onClose,
  onSave,
}: {
  task: Task | null;
  onClose: () => void;
  onSave: (t: Task) => void;
}) {
  const [draft, setDraft] = useState<Task | null>(task);
  useEffect(() => setDraft(task), [task]);
  if (!draft) return null;
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
      role="dialog"
      aria-modal
    >
      <div className="w-full max-w-xl rounded-2xl border bg-white p-4 shadow-xl dark:border-neutral-800 dark:bg-neutral-900">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-lg font-semibold">Edit Task</h3>
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
        </div>
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          <label className="flex flex-col gap-1 text-sm">
            <span className="opacity-70">Title</span>
            <input
              className="rounded-xl border bg-white px-3 py-2 text-sm dark:border-neutral-700 dark:bg-neutral-800"
              value={draft.title}
              onChange={(e) => setDraft({ ...draft, title: e.target.value })}
            />
          </label>
          <label className="flex flex-col gap-1 text-sm">
            <span className="opacity-70">Timeframe</span>
            <select
              className="rounded-xl border bg-white px-3 py-2 text-sm dark:border-neutral-700 dark:bg-neutral-800"
              value={draft.timeframe}
              onChange={(e) =>
                setDraft({ ...draft, timeframe: e.target.value as Timeframe })
              }
            >
              <option value="daily">Daily</option>
              <option value="weekly">Weekly</option>
              <option value="longterm">Long-term</option>
            </select>
          </label>
          {draft.timeframe === "weekly" && (
            <label className="flex flex-col gap-1 text-sm">
              <span className="opacity-70">Weekday</span>
              <select
                className="rounded-xl border bg-white px-3 py-2 text-sm dark:border-neutral-700 dark:bg-neutral-800"
                value={draft.weekday ?? new Date().getDay()}
                onChange={(e) =>
                  setDraft({ ...draft, weekday: parseInt(e.target.value) })
                }
              >
                {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map(
                  (d, i) => (
                    <option value={i} key={d}>
                      {d}
                    </option>
                  )
                )}
              </select>
            </label>
          )}
          {draft.timeframe === "longterm" && (
            <label className="flex flex-col gap-1 text-sm">
              <span className="opacity-70">Due Date</span>
              <input
                type="date"
                className="rounded-xl border bg-white px-3 py-2 text-sm dark:border-neutral-700 dark:bg-neutral-800"
                value={draft.dueDate ?? ""}
                onChange={(e) =>
                  setDraft({ ...draft, dueDate: e.target.value })
                }
              />
            </label>
          )}
          <label className="flex flex-col gap-1 text-sm">
            <span className="opacity-70">Priority</span>
            <input
              type="range"
              min={1}
              max={5}
              value={draft.priority}
              onChange={(e) =>
                setDraft({
                  ...draft,
                  priority: parseInt(e.target.value) as Priority,
                })
              }
            />
          </label>
          <label className="md:col-span-2 flex flex-col gap-1 text-sm">
            <span className="opacity-70">Notes</span>
            <textarea
              className="rounded-xl border bg-white px-3 py-2 text-sm dark:border-neutral-700 dark:bg-neutral-800"
              rows={3}
              value={draft.notes ?? ""}
              onChange={(e) =>
                setDraft({ ...draft, notes: e.target.value })
              }
            />
          </label>
        </div>
        <div className="mt-4 flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button
            onClick={() =>
              onSave({ ...draft, updatedAt: new Date().toISOString() } as Task)
            }
          >
            Save
          </Button>
        </div>
      </div>
    </div>
  );
}
